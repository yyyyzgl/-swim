
declare var config: Record<string, string | string[] | boolean>;
declare var theme: Record<string, string | string[] | boolean>;
