
interface JQuery {
  circleProgress(...args: any[]): JQuery;
}
